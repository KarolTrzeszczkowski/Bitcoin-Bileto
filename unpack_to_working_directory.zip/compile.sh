#! /bin/bash
label=''
number=''
msg="Usage: ./compile -l my_label [-n number] \n my_label - name of the batch chosen in bitcoin bileto plugin \n number - quantity od biletoj in the batch"
while getopts 'l:n:' flag; do
  case "${flag}" in
    l) label="$OPTARG" ;a=$(ls -1 --file-type ${label}_qrcodes | grep -v '/$' | wc -l);number=$(((a / 2)+1));;
    n) number=$OPTARG+1 ;;
    *) echo -e$msg
       exit 1 ;;
  esac
done
if [$label -eq '']; then
    echo -e $msg ; exit 2;
fi
echo $z
SEDCMD='s/\\setcounter{totalBiletoj}.*/\\setcounter{totalBiletoj}{'$number'}/'
SEDCMD2='s/\\newcommand{\\blabel}.*/\\newcommand{\\blabel}{'$label'}/'
echo $SEDCMD
sed $SEDCMD drawcard.tex |  sed $SEDCMD2 >> drawcard_tmp.tex

mv drawcard_tmp.tex drawcard.tex
pdflatex -synctex=1 -interaction=nonstopmode drawcard.tex
pdflatex -synctex=1 -interaction=nonstopmode full.tex
mv full.pdf $label.pdf

